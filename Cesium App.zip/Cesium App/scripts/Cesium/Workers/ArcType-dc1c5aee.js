define(["exports"],function(e){"use strict";var r=Object.freeze({NONE:0,GEODESIC:1,RHUMB:2});e.ArcType=r});
